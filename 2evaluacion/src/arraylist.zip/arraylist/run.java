package arraylist;

public class run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			alumno.main();
		} catch (Exception E) {
			E.printStackTrace();
		}
	}
}
