package equalsobrescrito;

public class run {
	public static void main(String[] args) {

		compara apellido = new compara();
		apellido.setApellido("Pepe");

	}

}
