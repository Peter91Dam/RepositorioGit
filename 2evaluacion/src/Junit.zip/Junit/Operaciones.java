package Junit;

public class Operaciones {
	
	
	public static int areacuadrado(int lado1, int lado2){
		return lado1*lado2;
	}
	
	public static int perimetrocuadrado(int lado1){
		return lado1*4;
	}
	
}


