package metodos;

import java.util.Scanner;

public class Main {
	
	public static void main (String[] args) {
		int x=0, numero=0;
		Scanner teclado=new Scanner(System.in);
		
		System.out.println("Introduce un numero para factorial iterativo");
		iterativo objeto=new iterativo();
		x=teclado.nextInt();
		System.out.println(objeto.factorialI(x));
		
		System.out.println("");
	
		
		System.out.println("Introduce un n�mero para calcular el factorial recursivo");
		recursivo ob=new recursivo();
		numero=teclado.nextInt();
		System.out.println(ob.factorial(numero));
		 
   }
}