package Tema7;

import java.util.Scanner;

public class Matriz {
	 private static int[][] matriz;

	public static void main (String[] args) {
		Scanner teclado = new Scanner(System.in);
		matriz=new int[2][3];
        for(int f=0;f<2;f++) {
            for(int c=0;c<3;c++) {
                System.out.print("Ingrese componentes de fila 1:" );
                matriz[f][c]=teclado.nextInt();              
            }     
        }
            for(int f=0;f<2;f++) {
                for(int c=0;c<3;c++) {               	
                	System.out.print(matriz[f][c]+" "); 
                	
                }
                System.out.println();
            }
          
}
	}

        
	

	